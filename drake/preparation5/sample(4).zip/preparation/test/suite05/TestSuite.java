package suite05;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	JSONTest.class
})

public class TestSuite {

}
